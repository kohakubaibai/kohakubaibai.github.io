var topic_speaker = [{
    // "nameZh": "曾正忠",
    // "nameEn": "Vincent Tseng",
    // "titleZh": "台大創創中心執行長",
    // "titleEn": "Taidah Entrepreneurship Center CEO",
    // "img": "VincentTseng.png",
    // "intro": '自2017年起擔任台大創創中心執行長，協助打造台灣的創新創業生態圈，促進新創團隊與中大型企業的合作，達成中大型企業成長轉型及新創驗證商業價值之目標。曾正忠為台大農藝學系兼任教授、宏碁基金會董事、企業外部創新顧問。曾任台灣飛利浦策略長兼品牌暨數位部門主管，擅長領域為外部創新、新事業發展。'
}]
